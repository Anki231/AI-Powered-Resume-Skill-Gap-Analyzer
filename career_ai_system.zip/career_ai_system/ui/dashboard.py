import streamlit as st
import requests
import json
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd

# Setting up page config
st.set_page_config(page_title="AI Career Navigator", page_icon="🚀", layout="wide")

# Modern CSS Styling for the Dashboard
st.markdown("""
<style>
    /* Gradient Headers */
    .title-banner {
        background: linear-gradient(90deg, #4b6cb7 0%, #182848 100%);
        padding: 2.5rem;
        border-radius: 15px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .section-header {
        background: linear-gradient(90deg, #00C9FF 0%, #92FE9D 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 800;
        font-size: 1.8rem;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }

    /* Cards */
    .card {
        background-color: #1e1e2f;
        padding: 1.5rem;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        margin-bottom: 1rem;
        border-left: 5px solid #00C9FF;
        color: #ffffff;
    }
    
    .card h4 {
        color: #00C9FF;
        margin-bottom: 0.5rem;
    }
    
    hr {
        border-color: #333;
    }

    /* Tags */
    .skill-tag {
        display: inline-block;
        padding: 0.3rem 0.8rem;
        margin: 0.2rem;
        border-radius: 20px;
        background-color: #2b2b40;
        color: #92FE9D;
        font-size: 0.9rem;
        font-weight: 600;
        border: 1px solid #4CAF50;
    }
    
    .missing-tag {
        display: inline-block;
        padding: 0.3rem 0.8rem;
        margin: 0.2rem;
        border-radius: 20px;
        background-color: #3b2023;
        color: #ff6b6b;
        font-size: 0.9rem;
        font-weight: 600;
        border: 1px solid #e74c3c;
    }
    
</style>
""", unsafe_allow_html=True)

# API Base URL
API_URL = "http://127.0.0.1:5000"

def main():
    st.markdown('<div class="title-banner"><h1>🚀 AI Career Navigator</h1><p style="font-size: 1.2rem;">Intelligent Resume Analysis & Job Recommendation System</p></div>', unsafe_allow_html=True)
    
    # Session Management
    if 'session_id' not in st.session_state:
        # Create a simple unique session ID based on timestamp
        import time
        st.session_state['session_id'] = f"user_{int(time.time())}"
        st.session_state['analyzed'] = False
        
    session_id = st.session_state['session_id']
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown('<div class="section-header">Upload Resume</div>', unsafe_allow_html=True)
        
        resume_input_type = st.radio("Resume Format:", ["Upload PDF", "Paste Text"], horizontal=True)
        resume_text = ""
        if resume_input_type == "Upload PDF":
            uploaded_file = st.file_uploader("Choose a PDF Resume", type="pdf")
            if uploaded_file is not None:
                import PyPDF2
                try:
                    pdf_reader = PyPDF2.PdfReader(uploaded_file)
                    for page in pdf_reader.pages:
                        page_text = page.extract_text()
                        if page_text:
                            resume_text += page_text + "\n"
                    st.success("PDF loaded successfully!")
                except Exception as e:
                    st.error(f"Error parsing PDF: {e}")
        else:
            resume_text = st.text_area("Paste your resume content here:", height=200, 
                                       placeholder="John Doe\nSoftware Engineer\nExperience with Python, React, ...")
        
        st.markdown('<div class="section-header">Job Match Type</div>', unsafe_allow_html=True)
        match_type = st.radio("Match against:", ["Database (Find Best Role)", "Custom Job Description"], horizontal=True)
        
        custom_job_desc = ""
        custom_job_title = "Custom Role"
        if match_type == "Custom Job Description":
            custom_job_title = st.text_input("Job Title:", "e.g. Senior Machine Learning Engineer")
            custom_job_desc = st.text_area("Paste the Job Description:", height=200)

        if st.button("🚀 Analyze & Match", use_container_width=True):
            if resume_text:
                if match_type == "Custom Job Description" and not custom_job_desc:
                    st.warning("Please enter a custom job description.")
                else:
                    with st.spinner("Analyzing resume using AI..."):
                        try:
                            # 1. Upload Resume
                            res = requests.post(f"{API_URL}/upload_resume", 
                                              json={"resume_text": resume_text, "session_id": session_id})
                            if res.status_code == 200:
                                # 2. Run match mode based on selection
                                if match_type == "Custom Job Description":
                                    payload = {
                                        "session_id": session_id,
                                        "job_title": custom_job_title,
                                        "job_description": custom_job_desc
                                    }
                                    res_match = requests.post(f"{API_URL}/match_custom_job", json=payload)
                                else:
                                    # Standard database match
                                    res_match = requests.get(f"{API_URL}/recommend_job", params={"session_id": session_id})
                                    
                                if res_match.status_code == 200:
                                    st.session_state['analyzed'] = True
                                    st.success("Analysis Complete!")
                                else:
                                    st.error("Failed to run job matching.")
                            else:
                                st.error("Failed to upload resume to backend.")
                        except requests.exceptions.ConnectionError:
                            st.error("Cannot connect to backend server. Make sure Flask API is running on port 5000.")
            else:
                st.warning("Please provide your resume first.")

    with col2:
        if st.session_state.get('analyzed'):
            try:
                # Top Row: AI Analysis & Match Score
                st.markdown('<div class="section-header">Best Job Match</div>', unsafe_allow_html=True)
                
                # For custom matches, recommend_job should not be called since we sent POST to match_custom_job instead.
                # However, for simplicity, we can fetch the session state by creating a new endpoint or just using a flag.
                # Since we don't have a GET endpoint for the current match_result, we can use the /recommend_job as is if we modify it to return current session match if it exists.
                # But to avoid re-running the model, let's add a quick fallback. 
                # Actually, the quickest way without a new endpoint is to make GET /recommend_job return the CURRENT match_result if the JobMatcher was run on a custom job. Let's fix app.py to just return session_store match_result if it's there.
                
                # Fetch job match from an arbitrary GET endpoint we already have or just add a quick /get_match_result endpoint
                match_res = requests.get(f"{API_URL}/get_match_result", params={"session_id": session_id}).json()
                
                # Fetch skills
                skills_res = requests.get(f"{API_URL}/analyze_resume", params={"session_id": session_id}).json()
                
                # Fetch skill gap
                gap_res = requests.get(f"{API_URL}/skill_gap", params={"session_id": session_id}).json()
                
                match_col1, match_col2 = st.columns([2, 1])
                
                with match_col1:
                    st.markdown(f"""
                    <div class="card">
                        <h4>🏆 Recommended Role</h4>
                        <h2>{match_res['job_title']}</h2>
                        <hr/>
                        <p>{match_res['description'][:200]}...</p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    st.markdown("<h5>Your Extracted Skills:</h5>", unsafe_allow_html=True)
                    skills_html = "".join([f'<span class="skill-tag">{skill}</span>' for skill in skills_res.get('skills', [])])
                    st.markdown(f"<div>{skills_html}</div><br/>", unsafe_allow_html=True)
                    
                with match_col2:
                    # Match Gauge Chart
                    score = match_res.get('similarity_score', 0)
                    color = "green" if score > 70 else "orange" if score > 40 else "red"
                    
                    fig = go.Figure(go.Indicator(
                        mode = "gauge+number",
                        value = score,
                        title = {'text': "AI Match Score", 'font': {'color': "#ffffff"}},
                        number= {'suffix': "%", 'font': {'color': "#00C9FF"}},
                        gauge = {
                            'axis': {'range': [None, 100], 'tickwidth': 1, 'tickcolor': "white"},
                            'bar': {'color': "#00C9FF"},
                            'bgcolor': "rgba(0,0,0,0)",
                            'borderwidth': 2,
                            'bordercolor': "gray",
                            'steps': [
                                {'range': [0, 50], 'color': 'rgba(255, 99, 132, 0.4)'},
                                {'range': [50, 80], 'color': 'rgba(255, 206, 86, 0.4)'},
                                {'range': [80, 100], 'color': 'rgba(75, 192, 192, 0.4)'}
                            ],
                        }
                    ))
                    fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", font={'color': "white"}, height=250, margin=dict(l=20, r=20, t=30, b=20))
                    st.plotly_chart(fig, use_container_width=True)
                    
                
                # Middle Row: Skill Gaps and Career Paths
                st.markdown('<div class="section-header">Skill Gap & Roadmap</div>', unsafe_allow_html=True)
                
                gap_col1, gap_col2 = st.columns(2)
                with gap_col1:
                    st.markdown("<h5>⚠️ Missing Skills for this Job:</h5>", unsafe_allow_html=True)
                    missing_skills_html = "".join([f'<span class="missing-tag">{skill}</span>' for skill in gap_res.get('missing_skills', [])])
                    if not missing_skills_html:
                        missing_skills_html = "<span style='color: #4CAF50;'>No missing skills! You're a perfect match.</span>"
                    st.markdown(f"<div>{missing_skills_html}</div><br/>", unsafe_allow_html=True)
                    
                with gap_col2:
                    # Fetch Career Paths
                    career_res = requests.get(f"{API_URL}/career_path", params={"session_id": session_id}).json()
                    paths = career_res.get('career_paths', [])
                    if paths:
                        st.markdown("<h5>🚀 Predicted Future Paths:</h5>", unsafe_allow_html=True)
                        for path in paths:
                            st.write(f"• **{path}**")
                            
                st.markdown("<h5>📚 Recommended Learning Roadmap:</h5>", unsafe_allow_html=True)
                roadmap = career_res.get('learning_roadmap', [])
                if roadmap:
                    rm_data = pd.DataFrame(roadmap)
                    st.dataframe(rm_data.rename(columns={'current': 'Based On', 'future_skill': 'Skill to Learn', 'demand_score': 'Market Demand'}), use_container_width=True)
                else:
                    st.info("Upload a resume with more technical skills to generate a roadmap.")
                    
                # Bottom Row: SHAP Explainability
                st.markdown('<div class="section-header">🧠 Explainable AI (SHAP)</div>', unsafe_allow_html=True)
                st.write("Understand why the AI recommended this job by viewing the feature contributions (terms matching the job description).")
                
                shap_res = requests.get(f"{API_URL}/explain", params={"session_id": session_id}).json()
                shap_data = shap_res.get('shap_data', [])
                
                if shap_data:
                    df_shap = pd.DataFrame(shap_data)
                    # Use a horizontal bar chart
                    fig_shap = px.bar(df_shap, x="contribution", y="feature", orientation='h',
                                     title="Keywords Influencing the Match",
                                     color="contribution", 
                                     color_continuous_scale="Viridis")
                    fig_shap.update_layout(yaxis={'categoryorder':'total ascending'}, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font={'color': "white"})
                    st.plotly_chart(fig_shap, use_container_width=True)
                else:
                    st.info("No significant keywords found to explain.")
            
            except Exception as e:
                st.error(f"Error fetching insights: {e}")
                
        else:
            # Landing Graphic
            st.info("👈 Upload your resume and click Analyze to generate your intelligent career dashboard.")

if __name__ == '__main__':
    main()
