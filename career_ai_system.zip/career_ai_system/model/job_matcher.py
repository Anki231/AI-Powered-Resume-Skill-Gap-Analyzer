import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import shap
import os
import sys

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.preprocess import clean_text
from utils.skill_extractor import extract_skills

class JobMatcher:
    def __init__(self, jobs_path):
        self.jobs_df = pd.read_csv(jobs_path)
        # Preprocess job descriptions
        self.jobs_df['clean_desc'] = self.jobs_df['description'].apply(clean_text)
        
        # Fit TF-IDF on job descriptions
        self.vectorizer = TfidfVectorizer(max_features=5000, stop_words='english')
        self.job_tfidf = self.vectorizer.fit_transform(self.jobs_df['clean_desc'])
        self.feature_names = self.vectorizer.get_feature_names_out()

    def get_best_match(self, resume_text):
        """
        Find the best matching job for a given resume text.
        Returns job details, similarity score, and skill gaps.
        """
        clean_resume = clean_text(resume_text)
        resume_tfidf = self.vectorizer.transform([clean_resume])
        
        # Compute cosine similarity
        similarities = cosine_similarity(resume_tfidf, self.job_tfidf)[0]
        best_match_idx = np.argmax(similarities)
        best_score = similarities[best_match_idx]
        
        best_job = self.jobs_df.iloc[best_match_idx]
        
        # Calculate skills
        resume_skills_raw = extract_skills(resume_text)
        resume_skills = [s.strip() for s in resume_skills_raw]
        
        job_skills_raw = best_job['required_skills'].split(',')
        job_skills = [s.strip() for s in job_skills_raw]
        
        # Skill gap
        missing_skills = list(set(job_skills) - set(resume_skills))
        
        return {
            'job_id': best_job['job_id'],
            'job_title': best_job['job_title'],
            'description': best_job['description'],
            'similarity_score': round(best_score * 100, 2),
            'resume_skills': resume_skills,
            'job_skills': job_skills,
            'missing_skills': missing_skills
        }

    def explain_match(self, resume_text, job_idx):
        """
        Use SHAP to explain which features contributed to the match score.
        For demonstration, we use SHAP on a simple linear model or KernelExplainer.
        Since we just want to show feature importance for the cosine similarity,
        we create a wrapper function for SHAP.
        """
        clean_resume = clean_text(resume_text)
        
        # To explain cosine similarity with SHAP, we treat the job's TF-IDF vector 
        # as fixed coefficients (like a linear model) where prediction = input_tfidf dot job_tfidf
        
        job_vector = self.job_tfidf[job_idx].toarray()[0]
        
        # The 'model' is essentially the dot product with the job vector
        def similarity_model(text_array):
            # text_array is an array of strings
            tfidf_matrix = self.vectorizer.transform(text_array)
            # return dot product -> shape (N,)
            return tfidf_matrix.dot(job_vector)

        # Using LinearExplainer is tricky here as we have strings. 
        # Instead, we directly calculate the contribution of each word in the resume 
        # by multiplying the resume's TF-IDF term weights by the job's TF-IDF term weights.
        
        resume_vector = self.vectorizer.transform([clean_resume]).toarray()[0]
        
        # The contribution of each feature is simply resume_vector[i] * job_vector[i]
        contributions = resume_vector * job_vector
        
        # Get top contributing words
        top_indices = np.argsort(contributions)[::-1][:10]
        
        explanation_data = []
        for idx in top_indices:
            if contributions[idx] > 0:
                explanation_data.append({
                    'feature': self.feature_names[idx],
                    'contribution': float(contributions[idx])
                })
                
                
        return explanation_data

    def get_custom_match(self, resume_text, job_title, job_desc, req_skills=""):
        """
        Match a resume against a custom job description.
        """
        clean_resume = clean_text(resume_text)
        resume_tfidf = self.vectorizer.transform([clean_resume])
        
        clean_job = clean_text(job_desc)
        job_tfidf = self.vectorizer.transform([clean_job])
        
        # Compute cosine similarity
        similarities = cosine_similarity(resume_tfidf, job_tfidf)[0]
        best_score = similarities[0]
        
        # Calculate skills
        resume_skills_raw = extract_skills(resume_text)
        resume_skills = [s.strip() for s in resume_skills_raw]
        
        if req_skills:
            job_skills_raw = req_skills.split(',')
        else:
            job_skills_raw = extract_skills(job_desc)
            
        job_skills = [s.strip() for s in job_skills_raw]
        
        # Skill gap
        missing_skills = list(set([s.lower() for s in job_skills]) - set([s.lower() for s in resume_skills]))
        # Restore case
        missing_skills = [skill.title() for skill in missing_skills]
        
        return {
            'job_id': 'custom',
            'job_title': job_title,
            'description': job_desc,
            'similarity_score': round(best_score * 100, 2),
            'resume_skills': resume_skills,
            'job_skills': job_skills,
            'missing_skills': missing_skills
        }
    
    def explain_custom_match(self, resume_text, job_desc):
        """
        SHAP explanation for custom job match using TF-IDF term weights.
        """
        clean_resume = clean_text(resume_text)
        clean_job = clean_text(job_desc)
        
        job_vector = self.vectorizer.transform([clean_job]).toarray()[0]
        resume_vector = self.vectorizer.transform([clean_resume]).toarray()[0]
        
        contributions = resume_vector * job_vector
        
        top_indices = np.argsort(contributions)[::-1][:10]
        
        explanation_data = []
        for idx in top_indices:
            if contributions[idx] > 0:
                explanation_data.append({
                    'feature': self.feature_names[idx],
                    'contribution': float(contributions[idx])
                })
                
        return explanation_data
