import os
import sys
import pandas as pd
from flask import Flask, request, jsonify

# Add absolute path to sys path to import other modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from model.job_matcher import JobMatcher
from utils.skill_extractor import extract_skills, compare_skills

app = Flask(__name__)

# Base paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, 'data')

# Initialize the job matcher
try:
    matcher = JobMatcher(os.path.join(DATA_DIR, 'jobs_main.csv'))
except Exception as e:
    print(f"Error initializing JobMatcher: {e}")
    matcher = None

# Load future skills dataset for career path/learning roadmap
try:
    future_skills_df = pd.read_csv(os.path.join(DATA_DIR, 'future_skills.csv'))
except Exception as e:
    print(f"Error loading future_skills.csv: {e}")
    future_skills_df = pd.DataFrame()

# In-memory session store (for simple demo purposes)
# In production, use a database or redis
session_store = {}


@app.route('/upload_resume', methods=['POST'])
def upload_resume():
    """
    Accepts resume text from UI and stores it holding a session ID
    """
    data = request.json
    if not data or 'resume_text' not in data:
        return jsonify({'error': 'No resume text provided'}), 400
    
    session_id = data.get('session_id', 'default_user')
    session_store[session_id] = {
        'resume_text': data['resume_text']
    }
    
    return jsonify({'status': 'success', 'message': 'Resume uploaded successfully'})


@app.route('/analyze_resume', methods=['GET'])
def analyze_resume():
    """
    Extract skills from the uploaded resume.
    """
    session_id = request.args.get('session_id', 'default_user')
    if session_id not in session_store:
        return jsonify({'error': 'No resume found for session'}), 404
    
    resume_text = session_store[session_id]['resume_text']
    skills = extract_skills(resume_text)
    
    # Save extracted skills to session
    session_store[session_id]['skills'] = skills
    
    return jsonify({'skills': skills})


@app.route('/recommend_job', methods=['GET'])
def recommend_job():
    """
    Match the resume with job descriptions and return best match.
    """
    session_id = request.args.get('session_id', 'default_user')
    if session_id not in session_store:
        return jsonify({'error': 'No resume found for session'}), 404
        
    resume_text = session_store[session_id]['resume_text']
    
    if not matcher:
        return jsonify({'error': 'Job Matcher not initialized'}), 500
        
    match_result = matcher.get_best_match(resume_text)
    
    # Store result in session for subsequent calls
    session_store[session_id]['match_result'] = match_result
    
    # Need to convert numpy types to native Python types for JSON
    res = {
        'job_title': match_result['job_title'],
        'description': match_result['description'],
        'similarity_score': float(match_result['similarity_score'])
    }
    
    return jsonify(res)


@app.route('/match_custom_job', methods=['POST'])
def match_custom_job():
    """
    Match the resume with a custom job description.
    """
    data = request.json
    if not data or 'job_description' not in data:
        return jsonify({'error': 'No job description provided'}), 400
        
    session_id = data.get('session_id', 'default_user')
    if session_id not in session_store:
        return jsonify({'error': 'No resume found for session'}), 404
        
    resume_text = session_store[session_id]['resume_text']
    job_desc = data['job_description']
    job_title = data.get('job_title', 'Custom Job Role')
    
    if not matcher:
        return jsonify({'error': 'Job Matcher not initialized'}), 500
        
    match_result = matcher.get_custom_match(resume_text, job_title, job_desc)
    
    # Store result in session for subsequent calls
    session_store[session_id]['match_result'] = match_result
    
    res = {
        'job_title': match_result['job_title'],
        'description': match_result['description'],
        'similarity_score': float(match_result['similarity_score'])
    }
    
    return jsonify(res)


@app.route('/get_match_result', methods=['GET'])
def get_match_result():
    """
    Return the current match result stored in the session.
    """
    session_id = request.args.get('session_id', 'default_user')
    if session_id not in session_store or 'match_result' not in session_store[session_id]:
        return jsonify({'error': 'Job match not performed yet'}), 404
        
    match_result = session_store[session_id]['match_result']
    res = {
        'job_title': match_result['job_title'],
        'description': match_result['description'],
        'similarity_score': float(match_result['similarity_score'])
    }
    return jsonify(res)


@app.route('/skill_gap', methods=['GET'])
def skill_gap():
    """
    Return missing skills for the matched job.
    """
    session_id = request.args.get('session_id', 'default_user')
    if session_id not in session_store or 'match_result' not in session_store[session_id]:
        return jsonify({'error': 'Job match not performed yet'}), 404
        
    match_result = session_store[session_id]['match_result']
    resume_skills = session_store[session_id].get('skills', [])
    
    job_skills_raw = [s.strip() for s in str(match_result.get('job_skills', '')).split(',')]
    if isinstance(match_result.get('job_skills'), list):
        job_skills_raw = match_result['job_skills']
        
    matched, missing = compare_skills(resume_skills, job_skills_raw)
    
    return jsonify({
        'matched_skills': matched,
        'missing_skills': missing
    })


@app.route('/career_path', methods=['GET'])
def career_path():
    """
    Returns possible career paths and future skills to learn.
    """
    session_id = request.args.get('session_id', 'default_user')
    if session_id not in session_store:
        return jsonify({'error': 'No resume found for session'}), 404
        
    resume_skills = session_store[session_id].get('skills', [])
    
    # Find matching future skills
    recommended_skills = []
    for skill in resume_skills:
        matches = future_skills_df[future_skills_df['current_skill'].str.lower() == skill.lower()]
        for _, row in matches.iterrows():
            recommended_skills.append({
                'current': skill,
                'future_skill': row['recommended_future_skill'],
                'demand_score': int(row['demand_score'])
            })
            
    # Remove duplicates and sort by demand score
    # (Simple logic for demo)
    unique_recs = {}
    for rec in recommended_skills:
        fs = rec['future_skill']
        if fs not in unique_recs or unique_recs[fs]['demand_score'] < rec['demand_score']:
            unique_recs[fs] = rec
            
    sorted_recs = sorted(list(unique_recs.values()), key=lambda x: x['demand_score'], reverse=True)
    
    # Dummy career path prediction based on match
    career_paths = []
    if 'match_result' in session_store[session_id]:
        job_title = session_store[session_id]['match_result']['job_title']
        if "Data" in job_title or "Machine" in job_title or "AI" in job_title:
            career_paths = ["Senior Data Scientist", "Lead AI Engineer", "Head of Data"]
        elif "Software" in job_title or "Developer" in job_title:
            career_paths = ["Senior Software Engineer", "Engineering Manager", "Software Architect"]
        elif "DevOps" in job_title or "Cloud" in job_title:
            career_paths = ["Senior Cloud Architect", "Director of Infrastructure"]
        else:
            career_paths = ["Senior " + job_title, "Principal " + job_title]
            
    return jsonify({
        'career_paths': career_paths,
        'learning_roadmap': sorted_recs[:5] # Top 5 skills
    })


@app.route('/explain', methods=['GET'])
def explain():
    """
    Return SHAP explanation data.
    """
    session_id = request.args.get('session_id', 'default_user')
    if session_id not in session_store or 'match_result' not in session_store[session_id]:
        return jsonify({'error': 'Job match not performed yet'}), 404
        
    resume_text = session_store[session_id]['resume_text']
    match_result = session_store[session_id]['match_result']
    
    if match_result.get('job_id') == 'custom':
        explanations = matcher.explain_custom_match(resume_text, match_result['description'])
    else:
        # We need to find the job_idx from the dataframe
        try:
            job_id = match_result['job_id']
            job_idx = matcher.jobs_df[matcher.jobs_df['job_id'] == job_id].index[0]
            explanations = matcher.explain_match(resume_text, job_idx)
        except Exception as e:
            explanations = [{'feature': 'error calculating SHAP', 'contribution': 0}]
        
    return jsonify({'shap_data': explanations})


if __name__ == '__main__':
    app.run(debug=True, port=5000)
