import re
import pandas as pd

# List of common tech skills for extraction
# In a real-world scenario, this could be loaded from an ontology or knowledge graph
TECH_SKILLS = set([
    'python', 'java', 'javascript', 'c++', 'c#', 'ruby', 'go', 'rust', 'swift', 'kotlin',
    'sql', 'nosql', 'mongodb', 'postgresql', 'mysql', 'redis', 'cassandra', 'elasticsearch',
    'html', 'css', 'react', 'vue', 'angular', 'node.js', 'django', 'flask', 'fastapi',
    'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'terraform', 'ansible', 'jenkins', 'ci/cd',
    'machine learning', 'deep learning', 'data science', 'pandas', 'scikit-learn', 'tensorflow',
    'pytorch', 'nlp', 'computer vision', 'data analysis', 'statistics', 'tableau', 'powerbi',
    'agile', 'scrum', 'jira', 'git', 'github', 'gitlab', 'linux', 'bash', 'shell scripting'
])

def extract_skills(text):
    """
    Extract skills from the provided text using a predefined skill vocabulary.
    """
    if not isinstance(text, str):
        return []
        
    text_lower = text.lower()
    
    # We want to match whole words/phrases for skills
    extracted = []
    for skill in TECH_SKILLS:
        # Create a regex to find whole words matching the skill
        # Escaping regex characters in skill (like C++)
        escaped_skill = re.escape(skill)
        # Using word boundaries to match exact phrases
        if re.search(r'\b' + escaped_skill + r'\b', text_lower):
            extracted.append(skill.title())
            
    # Also extract capitalized words as potential unlisted skills
    # (Simple heuristic for demonstration purposes)
    words = re.findall(r'\b[A-Z][a-zA-Z\.]+\b', text)
    potential_skills = [w for w in words if len(w) > 2 and w.lower() not in TECH_SKILLS]
    
    return list(set(extracted))

def compare_skills(resume_skills, job_skills):
    """
    Compare skills and return matched and missing skills.
    Assume both inputs are lists of strings.
    """
    resume_set = set([s.lower() for s in resume_skills])
    job_set = set([s.lower() for s in job_skills])
    
    matched = list(job_set.intersection(resume_set))
    missing = list(job_set.difference(resume_set))
    
    # Capitalize for display
    matched = [s.title() for s in matched]
    missing = [s.title() for s in missing]
    
    return matched, missing
