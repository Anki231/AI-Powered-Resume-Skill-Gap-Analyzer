import csv
import random
import os

# Define the path to the CSV file
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV_PATH = os.path.join(BASE_DIR, 'data', 'jobs_main.csv')

# Base data for generation
job_titles = [
    "Software Engineer", "Senior Software Engineer", "Backend Developer", "Frontend Developer", 
    "Full Stack Developer", "Data Scientist", "Senior Data Scientist", "Machine Learning Engineer",
    "AI Researcher", "Data Analyst", "Senior Data Analyst", "DevOps Engineer", "Cloud Architect",
    "Systems Administrator", "Database Administrator", "Product Manager", "UI/UX Designer",
    "QA Engineer", "Security Analyst", "Mobile Developer", "iOS Developer", "Android Developer"
]

skill_pools = {
    "Software Engineer": ["Python", "Java", "C++", "Git", "Agile", "SQL", "Docker", "REST APIs"],
    "Backend Developer": ["Python", "Node.js", "Ruby", "Golang", "PostgreSQL", "MongoDB", "Redis", "Docker", "Kubernetes", "AWS"],
    "Frontend Developer": ["JavaScript", "TypeScript", "React", "Vue", "Angular", "HTML", "CSS", "SASS", "UI/UX", "Webpack"],
    "Full Stack Developer": ["JavaScript", "React", "Node.js", "Python", "Django", "SQL", "NoSQL", "Git", "AWS"],
    "Data": ["Python", "R", "SQL", "Pandas", "NumPy", "Scikit-learn", "TensorFlow", "PyTorch", "Tableau", "PowerBI", "Machine Learning", "Deep Learning", "Statistics"],
    "DevOps/Cloud": ["AWS", "GCP", "Azure", "Docker", "Kubernetes", "Terraform", "CI/CD", "Jenkins", "Linux", "Bash", "Ansible", "Networking", "Security"],
    "Product": ["Agile", "Scrum", "Jira", "Product Roadmap", "Data Analysis", "Communication", "Leadership", "A/B Testing", "Stakeholder Management"],
    "Design": ["Figma", "Sketch", "Adobe XD", "UI/UX", "Wireframing", "Prototyping", "User Research", "Interaction Design"],
    "QA/Security": ["Selenium", "Cypress", "Jest", "PyTest", "Manual Testing", "Automated Testing", "Penetration Testing", "Network Security", "Cryptography"],
    "Mobile": ["Swift", "Kotlin", "Java", "React Native", "Flutter", "iOS", "Android", "Mobile UI", "CoreData"]
}

def get_mapping(title):
    if "Data" in title or "Machine" in title or "AI" in title:
        return skill_pools["Data"]
    elif "Frontend" in title:
        return skill_pools["Frontend"]
    elif "Backend" in title:
        return skill_pools["Backend"]
    elif "Full Stack" in title:
        return skill_pools["Full Stack"]
    elif "DevOps" in title or "Cloud" in title or "Systems" in title:
        return skill_pools["DevOps/Cloud"]
    elif "Product" in title:
        return skill_pools["Product"]
    elif "Design" in title:
        return skill_pools["Design"]
    elif "QA" in title or "Security" in title:
        return skill_pools["QA/Security"]
    elif "Mobile" in title or "iOS" in title or "Android" in title:
        return skill_pools["Mobile"]
    else:
        return skill_pools["Software Engineer"]

templates = [
    "We are looking for a highly skilled {title} to join our growing team. The ideal candidate will have strong experience with {s1}, {s2}, and {s3}. You will be responsible for building cutting-edge solutions.",
    "Exciting opportunity for a {title} with expertise in {s1} and {s2}. Join us to help scale our infrastructure and deliver high-quality products. {s4} is a plus.",
    "Seeking a motivated {title} to lead new initiatives. Must be proficient in {s1}, {s2}, {s3}, and {s4}. We offer a collaborative and innovative environment.",
    "Hiring a {title} to work on our core product line. Experience with {s2} and {s4} is required. If you love working with {s1}, apply today!",
    "Join our fast-paced startup as a {title}. You will design and implement systems using {s1}, {s2}, and {s3}. Strong communication skills and knowledge of {s4} expected."
]

def generate_job(job_id):
    title = random.choice(job_titles)
    pool = get_mapping(title)
    # Pick 4-7 skills
    num_skills = random.randint(4, min(7, len(pool)))
    skills = random.sample(pool, num_skills)
    
    # Generate description
    template = random.choice(templates)
    desc = template.format(
        title=title,
        s1=skills[0],
        s2=skills[1],
        s3=skills[2] if len(skills) > 2 else skills[0],
        s4=skills[3] if len(skills) > 3 else skills[1]
    )
    
    return {
        'job_id': job_id,
        'job_title': title,
        'description': desc,
        'required_skills': ", ".join(skills)
    }

def main():
    new_jobs = []
    # Start ID from 11 up to 300 to ensure we have well over 200 jobs total
    for i in range(11, 261):
        new_jobs.append(generate_job(i))
        
    file_exists = os.path.isfile(CSV_PATH)
    
    with open(CSV_PATH, 'a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['job_id', 'job_title', 'description', 'required_skills'], quoting=csv.QUOTE_MINIMAL)
        if not file_exists:
            writer.writeheader()
            
        for job in new_jobs:
            writer.writerow(job)
            
    print(f"Successfully added 250 new jobs to {CSV_PATH}")

if __name__ == '__main__':
    main()
